package com.imanage.interview.company;

import com.imanage.interview.cache.Cache;
import com.imanage.interview.cache.SimpleCache;
import java.util.List;
import org.springframework.stereotype.Service;

@Service("cachedCompanyService")
public class CachedCompanyService implements CompanyService {
    private final JdbcCompanyService companyService;
    private final Cache<Long, Company> companyCache;

    public CachedCompanyService(JdbcCompanyService companyService) {
        this.companyService = companyService;
        this.companyCache = new SimpleCache<>();
    }

    @Override
    public List<Company> getAllCompanies() {
        return companyService.getAllCompanies();
    }

    @Override
    public Company getById(Long id) {
        Company company = companyCache.get(id);
        if (company == null) {
            company = companyService.getById(id);
        }
        return company;
    }

    @Override
    public Company saveCompany(Company company) {
        var savedCompany = companyService.saveCompany(company);
        companyCache.put(savedCompany.getId(), savedCompany);
        return savedCompany;
    }

    @Override
    public Company updateCompany(Company company) {
        var updateCompany = companyService.updateCompany(company);
        companyCache.put(updateCompany.getId(), updateCompany);
        return updateCompany;
    }

    @Override
    public void deleteCompany(Long id) {
        companyService.deleteCompany(id);
    }
}
