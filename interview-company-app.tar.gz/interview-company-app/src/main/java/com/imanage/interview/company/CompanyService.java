package com.imanage.interview.company;

import java.util.List;

public interface CompanyService {
    List<Company> getAllCompanies();
    Company getById(Long id);
    Company saveCompany(Company company);
    Company updateCompany(Company company);
    void deleteCompany(Long id);
}
